# PDF Translator Pro

A starter full-stack Next.js app for translating Sanskrit, Hindi and English PDF books into Bengali.

## Run locally
1. Install Node.js 20 or newer.
2. In this folder run `npm install`.
3. Copy `.env.example` to `.env.local`.
4. Add your Google Gemini API key to `.env.local`.
5. Run `npm run dev` and open http://localhost:3000.

## Deploy
Push this project to a GitHub repository, import it into Vercel, and add `GEMINI_API_KEY` and `GEMINI_MODEL` as environment variables. Then deploy.

## Important limitations
- This is a starter implementation, not a fully production-hardened publishing system.
- Large books may need smaller chunks, retry/resume support, persistent job storage, and rate-limit handling.
- OCR quality depends on scan quality. Sanskrit OCR may require manual correction.
- The browser OCR language packs must be available to Tesseract.js; verify Sanskrit (`san`) data availability in your deployment.
- The current PDF export uses jsPDF's default font, which does not embed Bengali glyphs. DOCX export is preferable until an embeddable Bengali Unicode font is added.
- Sutra/verse/mantra identification is AI-assisted and must be proofread, especially in scholarly editions.
- Do not expose the Gemini API key in client-side code.
