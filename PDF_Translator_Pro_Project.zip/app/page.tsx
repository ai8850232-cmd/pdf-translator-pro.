 "use client";
import { useState } from "react";
import * as pdfjsLib from "pdfjs-dist";
import Tesseract from "tesseract.js";
import { Document, Packer, Paragraph, HeadingLevel } from "docx";
import { jsPDF } from "jspdf";

type Part = {page:number,text:string};
const RULES = `Translate source text directly into Bengali. Do not retain ordinary Sanskrit, Hindi, or English prose. Preserve only original Sanskrit sutras, shlokas, mantras and Vedic quotations exactly as supplied, followed immediately by their complete Bengali translation. Translate all commentary, bhashya, tika, varttika, explanations, headings, footnotes and descriptive prose into Bengali only. Do not invent, summarize, omit, or silently correct content. Preserve numbering, chapter order, references and paragraph structure. If unsure whether a Sanskrit passage is a verse/mantra/sutra or prose, preserve it only when its form and context clearly identify it; otherwise translate it into Bengali. Mark unreadable text [পাঠ অস্পষ্ট—যাচাই প্রয়োজন]. Output only the translated content.`;
export default function Home(){
 const [file,setFile]=useState<File|null>(null),[parts,setParts]=useState<Part[]>([]),[translated,setTranslated]=useState<string[]>([]);
 const [busy,setBusy]=useState(false),[status,setStatus]=useState("PDF নির্বাচন করুন।"),[progress,setProgress]=useState(0);
 const [ocr,setOcr]=useState(true),[model,setModel]=useState("gemini-2.5-flash");
 async function extract(){
  if(!file)return;setBusy(true);setStatus("PDF থেকে লেখা পড়া হচ্ছে…");setParts([]);setTranslated([]);
  try{
   const buf=await file.arrayBuffer();
   const pdfjs:any=pdfjsLib; pdfjs.GlobalWorkerOptions.workerSrc="/pdf.worker.min.mjs";
   const doc=await pdfjs.getDocument({data:buf}).promise;const out:Part[]=[];
   for(let i=1;i<=doc.numPages;i++){
    setStatus(`পৃষ্ঠা ${i}/${doc.numPages} পড়া হচ্ছে…`);
    const page=await doc.getPage(i);const content=await page.getTextContent();
    let txt=content.items.map((x:any)=>x.str).join(" ").trim();
    if(txt.length<35 && ocr){
      const viewport=page.getViewport({scale:1.8});const canvas=document.createElement("canvas");
      canvas.width=viewport.width;canvas.height=viewport.height;
      await page.render({canvas:canvas as any,viewport}).promise;
      const langs="eng+hin+san+ben";
      const result=await Tesseract.recognize(canvas,langs,{logger:()=>{}});
      txt=result.data.text.trim();
    }
    out.push({page:i,text:txt});
    setProgress(Math.round(i/doc.numPages*100));
   }
   setParts(out);setStatus(`${doc.numPages} পৃষ্ঠা থেকে লেখা সংগ্রহ করা হয়েছে।`);
  }catch(e:any){setStatus("PDF পড়তে সমস্যা হয়েছে: "+(e?.message||"Unknown error"))}
  finally{setBusy(false)}
 }
 async function translate(){
  if(!parts.length)return;setBusy(true);setTranslated([]);setProgress(0);
  try{
   const chunks:Part[][]=[];let current:Part[]=[];let count=0;
   for(const p of parts){current.push(p);count+=p.text.length;if(count>10000){chunks.push(current);current=[];count=0}}
   if(current.length)chunks.push(current);
   const results:string[]=[];
   for(let i=0;i<chunks.length;i++){
    setStatus(`বাংলা অনুবাদ হচ্ছে… অংশ ${i+1}/${chunks.length}`);
    const response=await fetch("/api/translate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:chunks[i].map(p=>`[পৃষ্ঠা ${p.page}]\\n${p.text}`).join("\\n\\n"),rules:RULES,model})});
    const data=await response.json();if(!response.ok)throw new Error(data.error||"Translation failed");
    results.push(data.translation);setTranslated([...results]);setProgress(Math.round((i+1)/chunks.length*100));
   }
   setStatus("অনুবাদ সম্পন্ন। অনুগ্রহ করে সূত্র/শ্লোক ও OCR মিলিয়ে যাচাই করুন।");
  }catch(e:any){setStatus("অনুবাদে সমস্যা: "+e.message)}
  finally{setBusy(false)}
 }
 async function exportDocx(){
  const paras=translated.join("\\n\\n").split("\\n").map(t=>new Paragraph({text:t}));
  const blob=await Packer.toBlob(new Document({sections:[{children:paras}]}));download(blob,"translated-bengali.docx");
 }
 function exportPdf(){
  const pdf=new jsPDF({unit:"pt",format:"a4"});pdf.setFont("helvetica");pdf.setFontSize(10);
  const lines=pdf.splitTextToSize(translated.join("\\n\\n"),500);let y=50;
  for(const line of lines){if(y>790){pdf.addPage();y=50}pdf.text(line,50,y);y+=15}
  pdf.save("translated-bengali.pdf");
 }
 function download(blob:Blob,name:string){const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;a.click();URL.revokeObjectURL(a.href)}
 return <main>
  <section className="hero"><h1>PDF Translator Pro</h1><p>সংস্কৃত, হিন্দি ও ইংরেজি বইয়ের সরাসরি বাংলা অনুবাদ</p><div className="small" style={{color:"#d9eee2"}}>শাস্ত্রীয় অনুবাদ • সূত্র-শ্লোক-মন্ত্র সংরক্ষণ • PDF/DOCX</div></section>
  <section className="panel"><h2>১. PDF বই আপলোড</h2><input type="file" accept="application/pdf,.pdf" onChange={e=>setFile(e.target.files?.[0]||null)}/>
   <label><input type="checkbox" checked={ocr} onChange={e=>setOcr(e.target.checked)} style={{width:"auto",marginRight:8}}/>স্ক্যান করা PDF হলে OCR ব্যবহার করুন</label>
   <p className="small">OCR-এর জন্য ইন্টারনেট সংযোগ প্রয়োজন হতে পারে। সংস্কৃত OCR-এর মান স্ক্যানের গুণমান ও ভাষা মডেলের ওপর নির্ভরশীল।</p>
   <button disabled={!file||busy} onClick={extract}>PDF থেকে লেখা পড়ুন</button>
  </section>
  <section className="panel"><h2>২. অনুবাদ সেটিংস</h2><div className="row"><div><label>মূল ভাষা</label><select defaultValue="auto"><option value="auto">স্বয়ংক্রিয় শনাক্তকরণ</option><option>সংস্কৃত</option><option>হিন্দি</option><option>ইংরেজি</option></select></div><div><label>অনুবাদের ভাষা</label><select value="বাংলা" disabled><option>বাংলা</option></select></div></div>
   <label>Gemini মডেল</label><select value={model} onChange={e=>setModel(e.target.value)}><option value="gemini-2.5-flash">Gemini 2.5 Flash</option><option value="gemini-2.5-pro">Gemini 2.5 Pro</option></select>
   <p className="small">নিয়ম: সাধারণ গদ্য বাংলায়; মূল সূত্র, শ্লোক, মন্ত্র ও বৈদিক উদ্ধৃতি মূল পাঠসহ তার বাংলা অনুবাদ।</p>
   <button disabled={!parts.length||busy} onClick={translate}>বাংলা অনুবাদ শুরু করুন</button>
  </section>
  <section className="panel"><h2>৩. অগ্রগতি</h2><div className="progress"><div className="bar" style={{width:progress+"%"}}/></div><div className="status">{status}</div><p className="small">পড়া পৃষ্ঠা: {parts.length} | অনুবাদ অংশ: {translated.length}</p></section>
  {translated.length>0&&<section className="panel"><h2>৪. অনূদিত বই</h2><div className="result">{translated.join("\\n\\n")}</div><div className="actions"><button onClick={exportDocx}>DOCX ডাউনলোড</button><button onClick={exportPdf}>PDF ডাউনলোড</button></div><p className="small">PDF export-এর বাংলা ফন্ট সঠিক রাখতে পরবর্তী সংস্করণে এমবেডেড বাংলা ফন্ট যোগ করুন। DOCX সাধারণত বাংলা ফন্ট ভালোভাবে সমর্থন করে।</p></section>}
  <p className="small">গোপনীয়তা: PDF ব্রাউজারে পড়া হয়; অনুবাদের জন্য extracted text আপনার Gemini API-তে পাঠানো হয়। API key কখনো এই পৃষ্ঠায় দেবেন না।</p>
 </main>
}