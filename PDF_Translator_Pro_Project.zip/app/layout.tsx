import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "PDF Translator Pro",
  description: "Scholarly PDF translation into Bengali"
};
export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
  return <html lang="bn"><body>{children}</body></html>;
}