import { NextResponse } from "next/server";
import { GoogleGenerativeAI } from "@google/generative-ai";
export const runtime = "nodejs";
export async function POST(req: Request) {
 try {
  const {text,rules,model}=await req.json();
  if(!process.env.GEMINI_API_KEY) return NextResponse.json({error:"সার্ভারে GEMINI_API_KEY সেট করা নেই।"}, {status:500});
  if(typeof text!=="string"||!text.trim()) return NextResponse.json({error:"অনুবাদের জন্য কোনো লেখা পাওয়া যায়নি।"},{status:400});
  const genAI=new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
  const chosen=["gemini-2.5-flash","gemini-2.5-pro"].includes(model)?model:"gemini-2.5-flash";
  const generativeModel=genAI.getGenerativeModel({model:chosen});
  const result=await generativeModel.generateContent(`${rules}\n\nTranslate the following source text into Bengali. Preserve page markers and their order. Do not claim missing text was translated.\n\nSOURCE:\n${text}`);
  return NextResponse.json({translation:result.response.text()});
 } catch(e:any) { return NextResponse.json({error:e?.message||"অনুবাদ ব্যর্থ হয়েছে।"},{status:500}); }
}